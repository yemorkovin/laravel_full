

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Редактировать новость</h2>
    <form method="POST" action="<?php echo e(route('article.update', $article)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Заголовок</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e($article->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="shortDesc">Содержимое</label>
            <textarea name="shortDesc" id="content" class="form-control" rows="5" required><?php echo e($article->shortDesc); ?></textarea>
        </div>
        <div class="form-group">
            <label for="shortDesc">Полный текст</label>
            <textarea name="shortDesc" id="content" class="form-control" rows="5" required><?php echo e($article->desc); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Обновить</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/article/edit.blade.php ENDPATH**/ ?>