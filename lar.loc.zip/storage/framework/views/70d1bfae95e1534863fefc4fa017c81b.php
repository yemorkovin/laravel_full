

<?php $__env->startSection('title', 'Главная страница'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1 class="display-4"><?php echo e($data['company_info']['title']); ?></h1>
        <p class="lead"><?php echo e($data['company_info']['content']); ?></p>
        <a href="<?php echo e($data['company_info']['preview_image']); ?>" class="btn btn-primary"><?php echo e($data['company_info']['button']); ?></a>
    </div>
    <h2>Последние новости</h2>
    <div class="row">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($item['name']); ?></h5>
                        <p><a href='/public/galery/<?php echo e($key+1); ?>'><img src='/public/<?php echo e($item["preview_image"]); ?>' width='100%'></a></p>
                        <?php if(isset($item['shortDesc'])): ?>
                        <p class="card-text"><?php echo e($item['shortDesc']); ?></p>
                        <?php endif; ?>
                        <a href="<?php echo e(route('article.show', $key+1)); ?>" class="btn btn-primary">Подробнее</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/pages/home.blade.php ENDPATH**/ ?>