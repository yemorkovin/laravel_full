

<?php $__env->startSection('title', 'Галерея'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
        <img src='/public/<?php echo e($full_image); ?>' width='100%'>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/pages/galery.blade.php ENDPATH**/ ?>