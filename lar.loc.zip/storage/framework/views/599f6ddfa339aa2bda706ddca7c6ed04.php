

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($articles->name); ?></h1>
    <p><?php echo e($articles->desc); ?></p>
    
    <h3>Комментарии:</h3>
    <?php $__currentLoopData = $articles->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <p><?php echo e($comment->content); ?></p>
            <p><small>Добавлено: <?php echo e($comment->created_at->diffForHumans()); ?></small></p>
            <?php if(auth()->check() && auth()->user()->role == 'moderator'): ?>
                <?php if($comment->approved): ?>
                    <button disabled class="btn btn-success">Одобрено</button>
                <?php else: ?>
                    <form method="POST" action="<?php echo e(route('comments.approve', $comment->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success">Одобрить</button>
                    </form>
                    <form method="POST" action="<?php echo e(route('comments.reject', $comment->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">Отклонить</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(auth()->check()): ?>
        <form method="POST" action="<?php echo e(route('comments.store', $articles->id)); ?>">
            <?php echo csrf_field(); ?>
            <textarea name="content" class="form-control" required></textarea>
            <button type="submit" class="btn btn-primary mt-2">Добавить комментарий</button>
        </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/article/show.blade.php ENDPATH**/ ?>