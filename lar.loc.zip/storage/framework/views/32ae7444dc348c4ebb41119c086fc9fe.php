<!DOCTYPE html>
<html>
<head>
    <title>Новый комментарий</title>
</head>
<body>
    <h1>Новый комментарий на вашу статью</h1>
    <p>Комментарий: <?php echo e($comment->content); ?></p>
    <p>Перейти к статье: <a href="<?php echo e(url('/articles/'.$comment->article_id)); ?>">Открыть статью</a></p>
</body>
</html>
<?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/emails/new_comment.blade.php ENDPATH**/ ?>