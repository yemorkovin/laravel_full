

<?php $__env->startSection('title', 'О нас'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <h2>О нашей компании</h2>
            <p>Мы занимаемся созданием современных новостных порталов для удобства пользователей.</p>
        </div>
        <div class="col-md-6">
            <img src="https://via.placeholder.com/500x300" class="img-fluid rounded" alt="О нас">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/pages/about.blade.php ENDPATH**/ ?>