

<?php $__env->startSection('title', 'Новости'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Последние новости</h2>
    <div class="row">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($item->name); ?></h5>
                        <p class="card-text"><?php echo e(Str::limit($item->shortDesc, 100)); ?></p>
                        <a href="<?php echo e(route('article.show', $item->id)); ?>" class="btn btn-primary">Подробнее</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($articles->links('pagination::bootstrap-5')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/article/index.blade.php ENDPATH**/ ?>