

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Новости</h2>
    <a href="<?php echo e(route('article.create')); ?>" class="btn btn-primary mb-3">Добавить новость</a>
    <table class="table">
        <thead>
            <tr>
                <th>Заголовок</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td>
                    <a href="<?php echo e(route('article.show', $item)); ?>" class="btn btn-success btn-sm">Просмотреть</a>
                    <a href="<?php echo e(route('article.edit', $item)); ?>" class="btn btn-warning btn-sm">Редактировать</a>
                    <form action="<?php echo e(route('article.destroy', $item)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Удалить</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($articles->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/article/add.blade.php ENDPATH**/ ?>