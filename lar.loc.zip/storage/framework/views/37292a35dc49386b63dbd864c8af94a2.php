<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Новостной сайт'); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Новостной сайт</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php if(request()->routeIs('home')): ?> active <?php endif; ?>" href="<?php echo e(route('home')); ?>">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if(request()->routeIs('about')): ?> active <?php endif; ?>" href="<?php echo e(route('about')); ?>">О нас</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if(request()->routeIs('contact')): ?> active <?php endif; ?>" href="<?php echo e(route('contact')); ?>">Контакты</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if(request()->routeIs('article.index')): ?> active <?php endif; ?>" href="<?php echo e(route('article.index')); ?>">Новости</a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-link nav-link" type="submit">Выйти</button>
                            </form>
                        </li>
                        <li class="nav-item nav-link">
                            Ваша роль <?php echo e(auth()->user()->role); ?>

                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login.form')); ?>">Войти</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('create.form')); ?>">Регистрация</a></li>
                    <?php endif; ?>
                    <?php if(auth()->check()): ?>
    <?php
        $notifications = auth()->user()->unreadNotifications;
    ?>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Уведомления (<?php echo e($notifications->count()); ?>)
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
            <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('article.show', $notification->data['id'])); ?>">
                        <?php echo e($notification->data['title']); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>
                    <a class="dropdown-item text-muted" href="#">Нет новых уведомлений</a>
                </li>
            <?php endif; ?>
        </ul>
        <div id="app">
            <notifications></notifications>
        </div>
    </li>
<?php endif; ?>

                </ul>
            </div>
        </div>
    </nav>

    <main class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="bg-dark text-white text-center py-3 mt-4">
        <p class="mb-0">&copy; Петров Иван Иванович гр. 444</p>
       
    </footer>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://js.pusher.com/beams/1.0/push-notifications-cdn.js"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\OSPanel6\home\lar.loc\resources\views/layouts/app.blade.php ENDPATH**/ ?>