<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class ArticleCreatedNotification extends Notification
{
    use Queueable;

    public $article;

    // Конструктор для передачи данных статьи
    public function __construct($article)
    {
        $this->article = $article;
    }

    // Указываем каналы уведомлений
    public function via($notifiable)
    {
        return ['database'];
    }

    // Данные для сохранения в БД
    public function toDatabase($notifiable)
    {
        return [
            'title' => $this->article->name,
            'id' => $this->article->id,
        ];
    }
}
