@extends('layouts.app')

@section('title', 'О нас')

@section('content')
    <div class="row">
        <div class="col-md-6">
            <h2>О нашей компании</h2>
            <p>Мы занимаемся созданием современных новостных порталов для удобства пользователей.</p>
        </div>
        <div class="col-md-6">
            <img src="https://via.placeholder.com/500x300" class="img-fluid rounded" alt="О нас">
        </div>
    </div>
@endsection
